using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace APPR6312_POE_Part_1.Pages.Admin
{
    public class Admin_ChoiceModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}
